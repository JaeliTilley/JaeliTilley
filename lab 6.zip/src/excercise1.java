public class excercise1 {
}
